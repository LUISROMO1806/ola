﻿using ChatBackend.Hubs;
using ChatBackend.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace ChatBackend.Controllers
{
    // CONTROLADOR DEL CHAT
    [RoutePrefix("api/chat")]
    public class ChatController : ApiController
    {
        // BASE DE DATOS
        private readonly ChatDBEntities db = new ChatDBEntities();

        // ARCHIVOS PERMITIDOS
        private static readonly HashSet<string> ExtensionesImagen =
            new HashSet<string> { ".jpg", ".jpeg", ".png", ".gif", ".webp" };

        private static readonly HashSet<string> ExtensionesAudio =
            new HashSet<string> { ".ogg", ".oga", ".opus", ".flac", ".wav", ".mp3", ".weba" };

        private static readonly HashSet<string> ExtensionesVideo =
            new HashSet<string> { ".mp4", ".webm", ".ogv", ".mkv", ".mov" };

        private static readonly HashSet<string> ExtensionesComprimido =
            new HashSet<string> { ".zip", ".rar", ".7z", ".tar", ".gz", ".tgz", ".bz2", ".xz" };

        private static readonly HashSet<string> ExtensionesDocumento =
            new HashSet<string> { ".pdf", ".odt", ".ods", ".odp", ".odg", ".txt", ".csv", ".md", ".rtf",
                                  ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx" };

        private static readonly HashSet<string> ExtensionesPermitidas =
            new HashSet<string>(ExtensionesImagen
                .Concat(ExtensionesAudio)
                .Concat(ExtensionesVideo)
                .Concat(ExtensionesComprimido)
                .Concat(ExtensionesDocumento));

        private const int TamanoMaximoBytes = 50 * 1024 * 1024;

        // DURACIONES DE FIJADO
        private static readonly int[] DiasFijadoPermitidos = { 1, 7, 30 };

        // CARPETA DE ARCHIVOS
        private const string CarpetaArchivos = "~/archivos/chat";

        // USUARIO ACTUAL (TODO-LOGIN: hoy sale del encabezado X-Usuario-Id, falsificable; no usar asi en produccion)
        private int UsuarioActualId
        {
            get
            {
                IEnumerable<string> valores;
                if (Request.Headers.TryGetValues("X-Usuario-Id", out valores))
                {
                    int id;
                    if (int.TryParse(valores.FirstOrDefault(), out id)) return id;
                }
                return 1;
            }
        }

        // LIBERAR CONEXION
        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }

        // LISTA DE CONVERSACIONES
        [HttpGet, Route("conversaciones")]
        public IHttpActionResult ObtenerConversaciones()
        {
            int yo = UsuarioActualId;

            var grupos = db.Mensajes
                .Where(m => m.RemitenteId == yo || m.DestinatarioId == yo)
                .GroupBy(m => m.RemitenteId == yo ? m.DestinatarioId : m.RemitenteId)
                .Select(g => new
                {
                    OtroId = g.Key,
                    UltimoId = g.Max(m => m.IdMensaje),
                    SinLeer = g.Count(m => m.DestinatarioId == yo && !m.Leido && !m.Eliminado)
                })
                .ToList();

            var otrosIds = grupos.Select(g => g.OtroId).ToList();
            var ultimosIds = grupos.Select(g => g.UltimoId).ToList();

            var personas = db.Usuarios
                .Where(u => otrosIds.Contains(u.UsuarioId))
                .ToDictionary(u => u.UsuarioId);

            var conectados = db.EstadoUsuario
                .Where(e => otrosIds.Contains(e.UsuarioId) && e.EnLinea)
                .Select(e => e.UsuarioId)
                .ToList();

            var ultimos = ConstruirDtos(
                db.Mensajes.Where(m => ultimosIds.Contains(m.IdMensaje)).ToList())
                .ToDictionary(d => d.Id);

            var resultado = grupos
                .Where(g => personas.ContainsKey(g.OtroId))
                .Select(g => new ConversacionDto
                {
                    UsuarioId = g.OtroId,
                    Nombre = personas[g.OtroId].NombreCompleto,
                    EnLinea = conectados.Contains(g.OtroId),
                    UltimoMensaje = ultimos[g.UltimoId],
                    SinLeer = g.SinLeer
                })
                .ToList();

            return Ok(resultado);
        }

        // BUSCAR USUARIOS
        [HttpGet, Route("~/api/usuarios")]
        public IHttpActionResult BuscarUsuarios(string nombre = "")
        {
            int yo = UsuarioActualId;
            nombre = (nombre ?? "").Trim();

            var coincidencias = db.Usuarios
                .Where(u => u.UsuarioId != yo && u.Activo && u.NombreCompleto.Contains(nombre))
                .OrderBy(u => u.NombreCompleto)
                .Take(20)
                .Select(u => new { u.UsuarioId, u.NombreCompleto })
                .ToList();

            var ids = coincidencias.Select(u => u.UsuarioId).ToList();
            var conectados = db.EstadoUsuario
                .Where(e => ids.Contains(e.UsuarioId) && e.EnLinea)
                .Select(e => e.UsuarioId)
                .ToList();

            var usuarios = coincidencias
                .Select(u => new UsuarioDto { Id = u.UsuarioId, Nombre = u.NombreCompleto, EnLinea = conectados.Contains(u.UsuarioId) })
                .ToList();

            return Ok(usuarios);
        }

        // HISTORIAL DE MENSAJES
        [HttpGet, Route("mensajes")]
        public IHttpActionResult ObtenerMensajes(int usuarioId)
        {
            int yo = UsuarioActualId;

            var lista = db.Mensajes
                .Where(m => (m.RemitenteId == yo && m.DestinatarioId == usuarioId)
                         || (m.RemitenteId == usuarioId && m.DestinatarioId == yo))
                .OrderBy(m => m.FechaEnvio)
                .ToList();

            return Ok(ConstruirDtos(lista));
        }

        // ENVIAR MENSAJE
        [HttpPost, Route("mensajes")]
        public async Task<IHttpActionResult> EnviarMensaje()
        {
            if (!Request.Content.IsMimeMultipartContent())
                return StatusCode(HttpStatusCode.UnsupportedMediaType);

            // LEER FORMULARIO
            var proveedor = new MultipartMemoryStreamProvider();
            await Request.Content.ReadAsMultipartAsync(proveedor);

            int destinatarioId = 0;
            long respuestaAId = 0;
            string texto = null;
            var subidos = new List<ArchivoSubido>();

            foreach (var parte in proveedor.Contents)
            {
                string campo = (parte.Headers.ContentDisposition.Name ?? "").Trim('"');
                string nombreArchivo = parte.Headers.ContentDisposition.FileName;

                if (!string.IsNullOrEmpty(nombreArchivo))
                {
                    nombreArchivo = Path.GetFileName(nombreArchivo.Trim('"'));
                    byte[] datos = await parte.ReadAsByteArrayAsync();
                    if (datos.Length == 0) continue;

                    string extension = Path.GetExtension(nombreArchivo).ToLowerInvariant();
                    if (!ExtensionesPermitidas.Contains(extension))
                        return BadRequest("El tipo de archivo '" + extension + "' no está permitido.");
                    if (datos.Length > TamanoMaximoBytes)
                        return BadRequest("El archivo '" + nombreArchivo + "' supera los " + (TamanoMaximoBytes / (1024 * 1024)) + " MB.");

                    subidos.Add(new ArchivoSubido
                    {
                        NombreOriginal = nombreArchivo,
                        Extension = extension,
                        TipoMime = parte.Headers.ContentType != null ? parte.Headers.ContentType.MediaType : null,
                        Datos = datos
                    });
                }
                else if (campo == "destinatarioId")
                {
                    int.TryParse(await parte.ReadAsStringAsync(), out destinatarioId);
                }
                else if (campo == "texto")
                {
                    texto = await parte.ReadAsStringAsync();
                }
                else if (campo == "respuestaAId")
                {
                    long.TryParse(await parte.ReadAsStringAsync(), out respuestaAId);
                }
            }

            // VALIDAR
            int yo = UsuarioActualId;
            texto = string.IsNullOrWhiteSpace(texto) ? null : texto.Trim();

            if (destinatarioId == yo)
                return BadRequest("No puedes enviarte mensajes a ti mismo.");
            if (!db.Usuarios.Any(u => u.UsuarioId == destinatarioId && u.Activo))
                return BadRequest("El destinatario no existe o no está activo.");
            if (texto == null && subidos.Count == 0)
                return BadRequest("El mensaje está vacío.");

            if (respuestaAId > 0)
            {
                bool citaValida = db.Mensajes.Any(m => m.IdMensaje == respuestaAId
                    && !m.Eliminado
                    && ((m.RemitenteId == yo && m.DestinatarioId == destinatarioId)
                     || (m.RemitenteId == destinatarioId && m.DestinatarioId == yo)));
                if (!citaValida)
                    return BadRequest("El mensaje que intentas responder no existe.");
            }

            // GUARDAR ARCHIVOS
            string carpetaFisica = HttpContext.Current.Server.MapPath(CarpetaArchivos);
            Directory.CreateDirectory(carpetaFisica);

            var mensaje = new Mensajes
            {
                RemitenteId = yo,
                DestinatarioId = destinatarioId,
                Texto = texto,
                FechaEnvio = DateTime.UtcNow,
                Leido = false,
                RespuestaAId = respuestaAId > 0 ? (long?)respuestaAId : null
            };

            foreach (var s in subidos)
            {
                string nombreGuardado = Guid.NewGuid().ToString("N") + s.Extension;
                File.WriteAllBytes(Path.Combine(carpetaFisica, nombreGuardado), s.Datos);

                mensaje.Archivos.Add(new Archivos
                {
                    NombreOriginal = s.NombreOriginal,
                    RutaServidor = "/archivos/chat/" + nombreGuardado,
                    TipoMime = s.TipoMime,
                    TamanoBytes = s.Datos.Length,
                    EsImagen = ExtensionesImagen.Contains(s.Extension)
                });
            }

            // GUARDAR MENSAJE
            db.Mensajes.Add(mensaje);
            db.SaveChanges();

            var dto = ConstruirDtos(new List<Mensajes> { mensaje })[0];

            string nombreRemitente = db.Usuarios.Where(u => u.UsuarioId == yo).Select(u => u.NombreCompleto).FirstOrDefault();
            ChatNotificador.MensajeNuevo(destinatarioId, dto, nombreRemitente);

            return Ok(dto);
        }

        // EDITAR MENSAJE
        [HttpPut, Route("mensajes/{id:long}")]
        public IHttpActionResult EditarMensaje(long id, [FromBody] EdicionRequest datos)
        {
            string texto = (datos == null || datos.Texto == null) ? "" : datos.Texto.Trim();
            if (texto.Length == 0)
                return BadRequest("El mensaje no puede quedar vacío.");

            var mensaje = db.Mensajes.Find(id);
            if (mensaje == null) return NotFound();

            if (mensaje.RemitenteId != UsuarioActualId)
                return StatusCode(HttpStatusCode.Forbidden);
            if (mensaje.Eliminado)
                return BadRequest("No se puede editar un mensaje eliminado.");

            mensaje.Texto = texto;
            mensaje.Editado = true;
            mensaje.FechaEdicion = DateTime.UtcNow;
            db.SaveChanges();

            return OkYAvisar(mensaje);
        }

        // ELIMINAR MENSAJE
        [HttpDelete, Route("mensajes/{id:long}")]
        public IHttpActionResult EliminarMensaje(long id)
        {
            var mensaje = db.Mensajes.Find(id);
            if (mensaje == null) return NotFound();

            if (mensaje.RemitenteId != UsuarioActualId)
                return StatusCode(HttpStatusCode.Forbidden);

            if (!mensaje.Eliminado)
            {
                var archivos = db.Archivos.Where(a => a.IdMensaje == id).ToList();
                foreach (var a in archivos)
                {
                    string ruta = HttpContext.Current.Server.MapPath("~" + a.RutaServidor);
                    try { if (File.Exists(ruta)) File.Delete(ruta); }
                    catch (IOException) { }
                    db.Archivos.Remove(a);
                }

                db.Reacciones.RemoveRange(db.Reacciones.Where(r => r.IdMensaje == id).ToList());

                mensaje.Texto = null;
                mensaje.Eliminado = true;
                mensaje.Fijado = false;
                mensaje.FechaFijado = null;
                mensaje.FijadoHasta = null;

                db.MensajesGuardados.RemoveRange(db.MensajesGuardados.Where(g => g.IdMensaje == id).ToList());
                db.SaveChanges();
            }

            return OkYAvisar(mensaje);
        }

        // FIJAR MENSAJE
        [HttpPost, Route("mensajes/{id:long}/fijar")]
        public IHttpActionResult FijarMensaje(long id, [FromBody] FijarRequest datos)
        {
            if (datos == null || !DiasFijadoPermitidos.Contains(datos.Dias))
                return BadRequest("Elige 1, 7 o 30 días.");

            int yo = UsuarioActualId;
            var mensaje = db.Mensajes.Find(id);
            if (mensaje == null) return NotFound();
            if (mensaje.Eliminado) return BadRequest("No se puede fijar un mensaje eliminado.");

            if (mensaje.RemitenteId != yo && mensaje.DestinatarioId != yo)
                return StatusCode(HttpStatusCode.Forbidden);

            var ahora = DateTime.UtcNow;
            mensaje.Fijado = true;
            mensaje.FechaFijado = ahora;
            mensaje.FijadoHasta = ahora.AddDays(datos.Dias);
            db.SaveChanges();

            return OkYAvisar(mensaje);
        }

        // QUITAR DE FIJADOS
        [HttpDelete, Route("mensajes/{id:long}/fijar")]
        public IHttpActionResult QuitarFijado(long id)
        {
            int yo = UsuarioActualId;
            var mensaje = db.Mensajes.Find(id);
            if (mensaje == null) return NotFound();
            if (mensaje.RemitenteId != yo && mensaje.DestinatarioId != yo)
                return StatusCode(HttpStatusCode.Forbidden);

            mensaje.Fijado = false;
            mensaje.FechaFijado = null;
            mensaje.FijadoHasta = null;
            db.SaveChanges();

            return OkYAvisar(mensaje);
        }

        // GUARDAR MENSAJE EN FAVORITOS
        [HttpPost, Route("mensajes/{id:long}/guardar")]
        public IHttpActionResult GuardarMensaje(long id)
        {
            int yo = UsuarioActualId;
            var mensaje = db.Mensajes.Find(id);
            if (mensaje == null) return NotFound();
            if (mensaje.Eliminado) return BadRequest("No se puede guardar un mensaje eliminado.");
            if (mensaje.RemitenteId != yo && mensaje.DestinatarioId != yo)
                return StatusCode(HttpStatusCode.Forbidden);

            if (!db.MensajesGuardados.Any(g => g.IdUsuario == yo && g.IdMensaje == id))
            {
                db.MensajesGuardados.Add(new MensajesGuardados
                {
                    IdUsuario = yo,
                    IdMensaje = id,
                    FechaGuardado = DateTime.UtcNow
                });
                db.SaveChanges();
            }

            return Ok(ConstruirDtos(new List<Mensajes> { mensaje })[0]);
        }

        // QUITAR DE GUARDADOS
        [HttpDelete, Route("mensajes/{id:long}/guardar")]
        public IHttpActionResult QuitarGuardado(long id)
        {
            int yo = UsuarioActualId;
            var mensaje = db.Mensajes.Find(id);
            if (mensaje == null) return NotFound();

            var fila = db.MensajesGuardados.FirstOrDefault(g => g.IdUsuario == yo && g.IdMensaje == id);
            if (fila != null)
            {
                db.MensajesGuardados.Remove(fila);
                db.SaveChanges();
            }

            return Ok(ConstruirDtos(new List<Mensajes> { mensaje })[0]);
        }

        // MENSAJES GUARDADOS
        [HttpGet, Route("guardados")]
        public IHttpActionResult ObtenerGuardados()
        {
            int yo = UsuarioActualId;

            var filas = db.MensajesGuardados
                .Where(g => g.IdUsuario == yo)
                .OrderByDescending(g => g.FechaGuardado)
                .Take(200)
                .ToList();

            var ids = filas.Select(g => g.IdMensaje).ToList();
            var mensajes = db.Mensajes.Where(m => ids.Contains(m.IdMensaje) && !m.Eliminado).ToList();
            var dtos = ConstruirDtos(mensajes).ToDictionary(x => x.Id);

            var otrosIds = mensajes
                .Select(m => m.RemitenteId == yo ? m.DestinatarioId : m.RemitenteId)
                .Distinct()
                .ToList();
            var nombres = db.Usuarios
                .Where(u => otrosIds.Contains(u.UsuarioId))
                .ToDictionary(u => u.UsuarioId, u => u.NombreCompleto);

            var resultado = filas
                .Where(g => dtos.ContainsKey(g.IdMensaje))
                .Select(g =>
                {
                    var dto = dtos[g.IdMensaje];
                    int otro = dto.RemitenteId == yo ? dto.DestinatarioId : dto.RemitenteId;
                    return new GuardadoDto
                    {
                        Mensaje = dto,
                        UsuarioId = otro,
                        Nombre = nombres.ContainsKey(otro) ? nombres[otro] : "Usuario",
                        FechaGuardado = DateTime.SpecifyKind(g.FechaGuardado, DateTimeKind.Utc)
                    };
                })
                .ToList();

            return Ok(resultado);
        }

        // BUSQUEDA DE MENSAJES Y ARCHIVOS
        [HttpGet, Route("buscar")]
        public IHttpActionResult Buscar(int usuarioId, string texto = null, string desde = null, string hasta = null)
        {
            int yo = UsuarioActualId;
            texto = string.IsNullOrWhiteSpace(texto) ? null : texto.Trim();
            DateTime? fechaDesde = LeerFecha(desde);
            DateTime? fechaHasta = LeerFecha(hasta);

            if (texto == null && !fechaDesde.HasValue && !fechaHasta.HasValue)
                return BadRequest("Escribe una palabra o elige una fecha.");

            var consulta = db.Mensajes.Where(m => !m.Eliminado
                && ((m.RemitenteId == yo && m.DestinatarioId == usuarioId)
                 || (m.RemitenteId == usuarioId && m.DestinatarioId == yo)));

            if (texto != null) consulta = consulta.Where(m => m.Texto.Contains(texto));
            if (fechaDesde.HasValue) { var d = fechaDesde.Value; consulta = consulta.Where(m => m.FechaEnvio >= d); }
            if (fechaHasta.HasValue) { var h = fechaHasta.Value; consulta = consulta.Where(m => m.FechaEnvio < h); }

            var mensajes = consulta.OrderByDescending(m => m.FechaEnvio).Take(100).ToList();

            return Ok(new BusquedaDto
            {
                Mensajes = ConstruirDtos(mensajes),
                Archivos = ConsultarArchivos(usuarioId, texto, "todos", fechaDesde, fechaHasta)
            });
        }

        // ARCHIVOS COMPARTIDOS
        [HttpGet, Route("archivos")]
        public IHttpActionResult ObtenerArchivos(int usuarioId, string nombre = null, string tipo = "todos")
        {
            return Ok(ConsultarArchivos(usuarioId, nombre, tipo, null, null));
        }

        // REACCIONES
        [HttpPost, Route("mensajes/{id:long}/reacciones")]
        public IHttpActionResult AlternarReaccion(long id, [FromBody] ReaccionRequest datos)
        {
            if (datos == null || string.IsNullOrWhiteSpace(datos.Emoji) || datos.Emoji.Length > 10)
                return BadRequest("Emoji no válido.");

            int yo = UsuarioActualId;
            var mensaje = db.Mensajes.Find(id);
            if (mensaje == null) return NotFound();
            if (mensaje.Eliminado) return BadRequest("No se puede reaccionar a un mensaje eliminado.");

            if (mensaje.RemitenteId != yo && mensaje.DestinatarioId != yo)
                return StatusCode(HttpStatusCode.Forbidden);

            var existente = db.Reacciones.FirstOrDefault(
                r => r.IdMensaje == id && r.IdUsuario == yo && r.Emoji == datos.Emoji);

            if (existente != null)
            {
                db.Reacciones.Remove(existente);
            }
            else
            {
                db.Reacciones.Add(new Reacciones
                {
                    IdMensaje = id,
                    IdUsuario = yo,
                    Emoji = datos.Emoji,
                    FechaReaccion = DateTime.UtcNow
                });
            }
            db.SaveChanges();

            var reacciones = ReaccionesDe(id);
            int otroReaccion = mensaje.RemitenteId == yo ? mensaje.DestinatarioId : mensaje.RemitenteId;
            ChatNotificador.ReaccionActualizada(otroReaccion, id, reacciones);

            return Ok(reacciones);
        }

        // MARCAR COMO LEIDO
        [HttpPut, Route("conversaciones/{usuarioId:int}/leido")]
        public IHttpActionResult MarcarComoLeido(int usuarioId)
        {
            int yo = UsuarioActualId;

            var pendientes = db.Mensajes
                .Where(m => m.DestinatarioId == yo && m.RemitenteId == usuarioId && !m.Leido)
                .ToList();

            foreach (var m in pendientes)
            {
                m.Leido = true;
                m.FechaLectura = DateTime.UtcNow;
            }
            db.SaveChanges();

            if (pendientes.Count > 0) ChatNotificador.MensajesLeidos(usuarioId, yo);

            return StatusCode(HttpStatusCode.NoContent);
        }

        // RESPUESTA CON AVISO A LA OTRA PERSONA
        private IHttpActionResult OkYAvisar(Mensajes mensaje)
        {
            var dto = ConstruirDtos(new List<Mensajes> { mensaje })[0];
            int otro = mensaje.RemitenteId == UsuarioActualId ? mensaje.DestinatarioId : mensaje.RemitenteId;
            ChatNotificador.MensajeActualizado(otro, dto);
            return Ok(dto);
        }

        // CONVERTIR MENSAJES A DTO
        private List<MensajeDto> ConstruirDtos(List<Mensajes> mensajes)
        {
            var ids = mensajes.Select(m => m.IdMensaje).ToList();

            var citadosIds = mensajes
                .Where(m => m.RespuestaAId.HasValue)
                .Select(m => m.RespuestaAId.Value)
                .Distinct()
                .ToList();
            var citados = citadosIds.Count == 0
                ? new List<Mensajes>()
                : db.Mensajes.Where(c => citadosIds.Contains(c.IdMensaje)).ToList();

            var todosIds = ids.Concat(citadosIds).Distinct().ToList();
            var archivos = db.Archivos.Where(a => todosIds.Contains(a.IdMensaje)).ToList();
            var reacciones = db.Reacciones.Where(r => ids.Contains(r.IdMensaje)).ToList();

            int yo = UsuarioActualId;
            var guardados = db.MensajesGuardados
                .Where(g => g.IdUsuario == yo && ids.Contains(g.IdMensaje))
                .Select(g => g.IdMensaje)
                .ToList();
            var ahora = DateTime.UtcNow;

            string urlBase = Request.RequestUri.GetLeftPart(UriPartial.Authority);

            return mensajes.Select(m =>
            {
                bool eliminado = m.Eliminado;

                CitaDto cita = null;
                if (m.RespuestaAId.HasValue)
                {
                    var c = citados.FirstOrDefault(x => x.IdMensaje == m.RespuestaAId.Value);
                    if (c != null)
                    {
                        cita = new CitaDto
                        {
                            Id = c.IdMensaje,
                            RemitenteId = c.RemitenteId,
                            Texto = c.Eliminado ? null : c.Texto,
                            Eliminado = c.Eliminado,
                            TieneArchivos = !c.Eliminado && archivos.Any(a => a.IdMensaje == c.IdMensaje)
                        };
                    }
                }

                return new MensajeDto
                {
                    Id = m.IdMensaje,
                    RemitenteId = m.RemitenteId,
                    DestinatarioId = m.DestinatarioId,
                    Texto = eliminado ? null : m.Texto,
                    Fecha = DateTime.SpecifyKind(m.FechaEnvio, DateTimeKind.Utc),
                    Leido = m.Leido,
                    Editado = m.Editado,
                    Eliminado = eliminado,
                    Fijado = !eliminado && EstaFijado(m, ahora),
                    FechaFijado = (!eliminado && EstaFijado(m, ahora) && m.FechaFijado.HasValue)
                        ? (DateTime?)DateTime.SpecifyKind(m.FechaFijado.Value, DateTimeKind.Utc)
                        : null,
                    FijadoHasta = (!eliminado && EstaFijado(m, ahora) && m.FijadoHasta.HasValue)
                        ? (DateTime?)DateTime.SpecifyKind(m.FijadoHasta.Value, DateTimeKind.Utc)
                        : null,
                    Guardado = !eliminado && guardados.Contains(m.IdMensaje),
                    RespuestaA = cita,
                    Archivos = eliminado
                        ? new List<ArchivoDto>()
                        : archivos
                            .Where(a => a.IdMensaje == m.IdMensaje)
                            .Select(a => new ArchivoDto
                            {
                                Nombre = a.NombreOriginal,
                                Url = urlBase + a.RutaServidor,
                                EsImagen = a.EsImagen,
                                Tipo = ClasificarTipo(a.NombreOriginal, a.EsImagen)
                            }).ToList(),
                    Reacciones = eliminado
                        ? new Dictionary<string, List<int>>()
                        : reacciones
                            .Where(r => r.IdMensaje == m.IdMensaje)
                            .GroupBy(r => r.Emoji)
                            .ToDictionary(g => g.Key, g => g.Select(r => r.IdUsuario).ToList())
                };
            }).ToList();
        }

        // CONSULTA DE ARCHIVOS
        private List<ArchivoCompartidoDto> ConsultarArchivos(int otroId, string nombre, string tipo, DateTime? desde, DateTime? hasta)
        {
            int yo = UsuarioActualId;

            var consulta = from a in db.Archivos
                           join m in db.Mensajes on a.IdMensaje equals m.IdMensaje
                           where !m.Eliminado
                              && ((m.RemitenteId == yo && m.DestinatarioId == otroId)
                               || (m.RemitenteId == otroId && m.DestinatarioId == yo))
                           select new
                           {
                               a.IdArchivo,
                               a.IdMensaje,
                               a.NombreOriginal,
                               a.RutaServidor,
                               a.TamanoBytes,
                               a.EsImagen,
                               m.RemitenteId,
                               m.FechaEnvio
                           };

            if (!string.IsNullOrWhiteSpace(nombre))
            {
                string n = nombre.Trim();
                consulta = consulta.Where(x => x.NombreOriginal.Contains(n));
            }
            if (desde.HasValue) { var d = desde.Value; consulta = consulta.Where(x => x.FechaEnvio >= d); }
            if (hasta.HasValue) { var h = hasta.Value; consulta = consulta.Where(x => x.FechaEnvio < h); }

            string urlBase = Request.RequestUri.GetLeftPart(UriPartial.Authority);

            var lista = consulta
                .OrderByDescending(x => x.FechaEnvio)
                .ToList()
                .Select(x => new ArchivoCompartidoDto
                {
                    Id = x.IdArchivo,
                    MensajeId = x.IdMensaje,
                    Nombre = x.NombreOriginal,
                    Url = urlBase + x.RutaServidor,
                    Tipo = ClasificarTipo(x.NombreOriginal, x.EsImagen),
                    Tamano = x.TamanoBytes,
                    Fecha = DateTime.SpecifyKind(x.FechaEnvio, DateTimeKind.Utc),
                    RemitenteId = x.RemitenteId
                });

            if (!string.IsNullOrEmpty(tipo) && tipo != "todos")
                lista = lista.Where(f => f.Tipo == tipo);

            return lista.Take(200).ToList();
        }

        // ESTADO DE FIJADO
        private static bool EstaFijado(Mensajes m, DateTime ahora)
        {
            return m.Fijado && (!m.FijadoHasta.HasValue || m.FijadoHasta.Value > ahora);
        }

        // TIPO DE ARCHIVO
        private static string ClasificarTipo(string nombre, bool esImagen)
        {
            string extension = Path.GetExtension(nombre ?? "").ToLowerInvariant();
            if (esImagen || ExtensionesImagen.Contains(extension)) return "imagen";
            if (ExtensionesAudio.Contains(extension)) return "audio";
            if (ExtensionesVideo.Contains(extension)) return "video";
            if (ExtensionesComprimido.Contains(extension)) return "comprimido";
            return "documento";
        }

        // LECTURA DE FECHAS
        private static DateTime? LeerFecha(string texto)
        {
            DateTime fecha;
            if (!string.IsNullOrWhiteSpace(texto)
                && DateTime.TryParse(texto, CultureInfo.InvariantCulture,
                    DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out fecha))
                return fecha;
            return null;
        }

        // REACCIONES DE UN MENSAJE
        private Dictionary<string, List<int>> ReaccionesDe(long mensajeId)
        {
            return db.Reacciones
                .Where(r => r.IdMensaje == mensajeId)
                .ToList()
                .GroupBy(r => r.Emoji)
                .ToDictionary(g => g.Key, g => g.Select(r => r.IdUsuario).ToList());
        }

        // ARCHIVO RECIEN SUBIDO
        private class ArchivoSubido
        {
            public string NombreOriginal;
            public string Extension;
            public string TipoMime;
            public byte[] Datos;
        }
    }
}
