﻿using ChatBackend.Models;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading.Tasks;

namespace ChatBackend.Hubs
{
    // HUB DEL CHAT
    [HubName("chatHub")]
    public class ChatHub : Hub
    {
        // CONEXIONES ABIERTAS POR USUARIO
        private static readonly ConcurrentDictionary<int, int> Conexiones = new ConcurrentDictionary<int, int>();

        // GRUPO DE UN USUARIO
        public static string Grupo(int usuarioId)
        {
            return "usuario-" + usuarioId;
        }

        // USUARIO CONECTADO (TODO-LOGIN: tomarlo del token o la sesion, no del query string)
        private int UsuarioActualId
        {
            get
            {
                int id;
                return int.TryParse(Context.QueryString["usuarioId"], out id) ? id : 0;
            }
        }

        // CONEXION NUEVA
        public override async Task OnConnected()
        {
            int id = UsuarioActualId;
            if (id > 0 && UsuarioActivo(id))
            {
                await Groups.Add(Context.ConnectionId, Grupo(id));

                if (Conexiones.AddOrUpdate(id, 1, (clave, total) => total + 1) == 1)
                {
                    GuardarEstado(id, true);
                    Clients.Others.estadoCambiado(id, true);
                }
            }
            await base.OnConnected();
        }

        // CONEXION CERRADA
        public override async Task OnDisconnected(bool stopCalled)
        {
            int id = UsuarioActualId;
            if (id > 0 && Conexiones.ContainsKey(id))
            {
                int restantes = Conexiones.AddOrUpdate(id, 0, (clave, total) => Math.Max(0, total - 1));
                if (restantes == 0)
                {
                    int descartado;
                    Conexiones.TryRemove(id, out descartado);
                    GuardarEstado(id, false);
                    Clients.All.estadoCambiado(id, false);
                }
            }
            await base.OnDisconnected(stopCalled);
        }

        // REINICIAR ESTADOS AL ARRANCAR EL SERVIDOR
        public static void ReiniciarEstados()
        {
            try
            {
                using (var db = new ChatDBEntities())
                {
                    db.Database.ExecuteSqlCommand("UPDATE chat.EstadoUsuario SET EnLinea = 0");
                }
            }
            catch (Exception)
            {
            }
        }

        // USUARIO EXISTENTE Y ACTIVO
        private static bool UsuarioActivo(int id)
        {
            using (var db = new ChatDBEntities())
            {
                return db.Usuarios.Any(u => u.UsuarioId == id && u.Activo);
            }
        }

        // GUARDAR ESTADO EN LA BASE
        private static void GuardarEstado(int id, bool enLinea)
        {
            using (var db = new ChatDBEntities())
            {
                var estado = db.EstadoUsuario.FirstOrDefault(e => e.UsuarioId == id);
                if (estado == null)
                {
                    estado = new EstadoUsuario { UsuarioId = id };
                    db.EstadoUsuario.Add(estado);
                }
                estado.EnLinea = enLinea;
                estado.UltimaConexion = DateTime.UtcNow;
                db.SaveChanges();
            }
        }
    }
}
