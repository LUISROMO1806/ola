﻿using System;
using System.Collections.Generic;
using ChatBackend.Models;
using Microsoft.AspNet.SignalR;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;

namespace ChatBackend.Hubs
{
    // AVISOS EN TIEMPO REAL DESDE EL CONTROLADOR
    public static class ChatNotificador
    {
        // JSON EN camelCase SOLO PARA LOS DATOS DEL CHAT
        private static readonly JsonSerializer Serializador = JsonSerializer.Create(new JsonSerializerSettings
        {
            ContractResolver = new CamelCasePropertyNamesContractResolver(),
            DateTimeZoneHandling = DateTimeZoneHandling.Utc
        });

        // CONVERTIR A JSON
        private static JToken Convertir(object datos)
        {
            return JToken.FromObject(datos, Serializador);
        }

        // CLIENTES DE UN USUARIO
        private static dynamic Cliente(int usuarioId)
        {
            return GlobalHost.ConnectionManager.GetHubContext<ChatHub>().Clients.Group(ChatHub.Grupo(usuarioId));
        }

        // MENSAJE NUEVO
        public static void MensajeNuevo(int destinatarioId, MensajeDto mensaje, string nombreRemitente)
        {
            Enviar(() => Cliente(destinatarioId).recibirMensaje(Convertir(mensaje), nombreRemitente));
        }

        // MENSAJE EDITADO, ELIMINADO O FIJADO
        public static void MensajeActualizado(int usuarioId, MensajeDto mensaje)
        {
            Enviar(() => Cliente(usuarioId).mensajeActualizado(Convertir(mensaje)));
        }

        // REACCION NUEVA O QUITADA
        public static void ReaccionActualizada(int usuarioId, long mensajeId, Dictionary<string, List<int>> reacciones)
        {
            Enviar(() => Cliente(usuarioId).reaccionActualizada(mensajeId, Convertir(reacciones)));
        }

        // MENSAJES LEIDOS
        public static void MensajesLeidos(int remitenteId, int lectorId)
        {
            Enviar(() => Cliente(remitenteId).mensajesLeidos(lectorId));
        }

        // ENVIAR SIN ROMPER LA PETICION
        private static void Enviar(Action accion)
        {
            try
            {
                accion();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("[hub] " + ex);
            }
        }
    }
}