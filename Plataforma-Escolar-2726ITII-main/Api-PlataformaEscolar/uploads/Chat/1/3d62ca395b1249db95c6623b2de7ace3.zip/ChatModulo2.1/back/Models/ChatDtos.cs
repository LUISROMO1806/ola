﻿using System;
using System.Collections.Generic;

namespace ChatBackend.Models
{
    // USUARIO DEL BUSCADOR
    public class UsuarioDto
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public bool EnLinea { get; set; }
    }

    // ARCHIVO DE UN MENSAJE
    public class ArchivoDto
    {
        public string Nombre { get; set; }
        public string Url { get; set; }
        public bool EsImagen { get; set; }
        public string Tipo { get; set; }
    }

    // MENSAJE CITADO
    public class CitaDto
    {
        public long Id { get; set; }
        public int RemitenteId { get; set; }
        public string Texto { get; set; }
        public bool Eliminado { get; set; }
        public bool TieneArchivos { get; set; }
    }

    // MENSAJE
    public class MensajeDto
    {
        public long Id { get; set; }
        public int RemitenteId { get; set; }
        public int DestinatarioId { get; set; }
        public string Texto { get; set; }
        public DateTime Fecha { get; set; }
        public bool Leido { get; set; }
        public bool Editado { get; set; }
        public bool Eliminado { get; set; }
        public bool Fijado { get; set; }
        public DateTime? FechaFijado { get; set; }
        public DateTime? FijadoHasta { get; set; }
        public bool Guardado { get; set; }
        public CitaDto RespuestaA { get; set; }
        public List<ArchivoDto> Archivos { get; set; }
        public Dictionary<string, List<int>> Reacciones { get; set; }
    }

    // ARCHIVO COMPARTIDO
    public class ArchivoCompartidoDto
    {
        public long Id { get; set; }
        public long MensajeId { get; set; }
        public string Nombre { get; set; }
        public string Url { get; set; }
        public string Tipo { get; set; }
        public long? Tamano { get; set; }
        public DateTime Fecha { get; set; }
        public int RemitenteId { get; set; }
    }

    // RESULTADO DE BUSQUEDA
    public class BusquedaDto
    {
        public List<MensajeDto> Mensajes { get; set; }
        public List<ArchivoCompartidoDto> Archivos { get; set; }
    }

    // CONVERSACION DE LA LISTA
    public class ConversacionDto
    {
        public int UsuarioId { get; set; }
        public string Nombre { get; set; }
        public bool EnLinea { get; set; }
        public MensajeDto UltimoMensaje { get; set; }
        public int SinLeer { get; set; }
    }

    // PETICION DE FIJAR
    public class FijarRequest
    {
        public int Dias { get; set; }
    }

    // MENSAJE GUARDADO
    public class GuardadoDto
    {
        public MensajeDto Mensaje { get; set; }
        public int UsuarioId { get; set; }
        public string Nombre { get; set; }
        public DateTime FechaGuardado { get; set; }
    }

    // PETICION DE EDITAR
    public class EdicionRequest
    {
        public string Texto { get; set; }
    }

    // PETICION DE REACCIONAR
    public class ReaccionRequest
    {
        public string Emoji { get; set; }
    }
}
