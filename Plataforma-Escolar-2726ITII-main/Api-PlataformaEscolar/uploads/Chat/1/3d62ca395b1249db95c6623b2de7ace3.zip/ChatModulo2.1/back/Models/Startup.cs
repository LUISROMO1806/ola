﻿using System.Threading.Tasks;
using System.Web.Cors;
using ChatBackend.Hubs;
using Microsoft.AspNet.SignalR;
using Microsoft.Owin;
using Microsoft.Owin.Cors;
using Owin;

[assembly: OwinStartup(typeof(ChatBackend.Startup))]

namespace ChatBackend
{
    // INICIO DEL TIEMPO REAL
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            // CORS (mismos origenes que WebApiConfig.cs)
            var politica = new CorsPolicy
            {
                AllowAnyHeader = true,
                AllowAnyMethod = true,
                SupportsCredentials = true
            };
            politica.Origins.Add("http://127.0.0.1:5500");
            politica.Origins.Add("http://localhost:5500");

            var cors = new CorsOptions
            {
                PolicyProvider = new CorsPolicyProvider
                {
                    PolicyResolver = contexto => Task.FromResult(politica)
                }
            };

            // RUTA /signalr
            app.Map("/signalr", mapa =>
            {
                mapa.UseCors(cors);
                mapa.RunSignalR(new HubConfiguration());
            });

            // TODOS DESCONECTADOS AL ARRANCAR
            ChatHub.ReiniciarEstados();
        }
    }
}