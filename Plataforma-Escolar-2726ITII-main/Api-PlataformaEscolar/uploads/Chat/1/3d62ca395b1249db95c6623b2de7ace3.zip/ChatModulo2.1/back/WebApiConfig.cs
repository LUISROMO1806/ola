﻿using System.Web.Http;
using System.Web.Http.Cors;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace ChatBackend
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // CORS (mismos origenes que Startup.cs)
            var cors = new EnableCorsAttribute(
                origins: "http://127.0.0.1:5500,http://localhost:5500",
                headers: "*",
                methods: "*");
            config.EnableCors(cors);

            // FORMATO JSON
            config.Formatters.Remove(config.Formatters.XmlFormatter);

            var json = config.Formatters.JsonFormatter;
            json.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
            json.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Utc;

            // RUTAS
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
