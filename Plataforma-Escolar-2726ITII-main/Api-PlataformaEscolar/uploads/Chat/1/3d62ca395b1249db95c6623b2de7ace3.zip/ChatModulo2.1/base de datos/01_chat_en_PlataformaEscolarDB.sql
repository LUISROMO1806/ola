USE PlataformaEscolarDB;

-- ESQUEMA
IF SCHEMA_ID(N'chat') IS NULL
    EXEC (N'CREATE SCHEMA chat');

-- ESTADO EN LINEA
IF OBJECT_ID(N'chat.EstadoUsuario', N'U') IS NULL
BEGIN
    CREATE TABLE chat.EstadoUsuario
    (
        UsuarioId      INT       NOT NULL CONSTRAINT PK_ChatEstadoUsuario PRIMARY KEY
                                 CONSTRAINT FK_ChatEstadoUsuario_Usuarios REFERENCES dbo.Usuarios (UsuarioId) ON DELETE CASCADE,
        EnLinea        BIT       NOT NULL CONSTRAINT DF_ChatEstadoUsuario_EnLinea DEFAULT (0),
        UltimaConexion DATETIME2 NULL
    );
END

-- MENSAJES
IF OBJECT_ID(N'chat.Mensajes', N'U') IS NULL
BEGIN
    CREATE TABLE chat.Mensajes
    (
        IdMensaje      BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ChatMensajes PRIMARY KEY,
        RemitenteId    INT           NOT NULL CONSTRAINT FK_ChatMensajes_Remitente    REFERENCES dbo.Usuarios (UsuarioId),
        DestinatarioId INT           NOT NULL CONSTRAINT FK_ChatMensajes_Destinatario REFERENCES dbo.Usuarios (UsuarioId),
        Texto          NVARCHAR(MAX) NULL,
        FechaEnvio     DATETIME2     NOT NULL CONSTRAINT DF_ChatMensajes_Fecha     DEFAULT (SYSUTCDATETIME()),
        Leido          BIT           NOT NULL CONSTRAINT DF_ChatMensajes_Leido     DEFAULT (0),
        FechaLectura   DATETIME2     NULL,
        Editado        BIT           NOT NULL CONSTRAINT DF_ChatMensajes_Editado   DEFAULT (0),
        FechaEdicion   DATETIME2     NULL,
        Eliminado      BIT           NOT NULL CONSTRAINT DF_ChatMensajes_Eliminado DEFAULT (0),
        RespuestaAId   BIGINT        NULL CONSTRAINT FK_ChatMensajes_RespuestaA REFERENCES chat.Mensajes (IdMensaje),
        Fijado         BIT           NOT NULL CONSTRAINT DF_ChatMensajes_Fijado    DEFAULT (0),
        FechaFijado    DATETIME2     NULL,
        FijadoHasta    DATETIME2     NULL,
        CONSTRAINT CK_ChatMensajes_DistintasPersonas CHECK (RemitenteId <> DestinatarioId),
        INDEX IX_ChatMensajes_Historial (RemitenteId, DestinatarioId, FechaEnvio),
        INDEX IX_ChatMensajes_SinLeer (DestinatarioId, Leido)
    );
END

-- COLUMNA FijadoHasta (SOLO SI EL CHAT SE INSTALO ANTES DE LAS DURACIONES)
IF COL_LENGTH(N'chat.Mensajes', N'FijadoHasta') IS NULL
    ALTER TABLE chat.Mensajes ADD FijadoHasta DATETIME2 NULL;

-- ARCHIVOS ADJUNTOS
IF OBJECT_ID(N'chat.Archivos', N'U') IS NULL
BEGIN
    CREATE TABLE chat.Archivos
    (
        IdArchivo      BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ChatArchivos PRIMARY KEY,
        IdMensaje      BIGINT        NOT NULL CONSTRAINT FK_ChatArchivos_Mensaje REFERENCES chat.Mensajes (IdMensaje) ON DELETE CASCADE,
        NombreOriginal NVARCHAR(260) NOT NULL,
        RutaServidor   NVARCHAR(500) NOT NULL,
        TipoMime       NVARCHAR(100) NULL,
        TamanoBytes    BIGINT        NULL,
        EsImagen       BIT           NOT NULL CONSTRAINT DF_ChatArchivos_EsImagen DEFAULT (0),
        INDEX IX_ChatArchivos_Mensaje (IdMensaje)
    );
END

-- REACCIONES
IF OBJECT_ID(N'chat.Reacciones', N'U') IS NULL
BEGIN
    CREATE TABLE chat.Reacciones
    (
        IdMensaje     BIGINT       NOT NULL CONSTRAINT FK_ChatReacciones_Mensaje  REFERENCES chat.Mensajes (IdMensaje) ON DELETE CASCADE,
        IdUsuario     INT          NOT NULL CONSTRAINT FK_ChatReacciones_Usuarios REFERENCES dbo.Usuarios (UsuarioId),
        Emoji         NVARCHAR(10) NOT NULL,
        FechaReaccion DATETIME2    NOT NULL CONSTRAINT DF_ChatReacciones_Fecha DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT PK_ChatReacciones PRIMARY KEY (IdMensaje, IdUsuario, Emoji)
    );
END

-- MENSAJES GUARDADOS
IF OBJECT_ID(N'chat.MensajesGuardados', N'U') IS NULL
BEGIN
    CREATE TABLE chat.MensajesGuardados
    (
        IdUsuario     INT       NOT NULL CONSTRAINT FK_ChatGuardados_Usuarios REFERENCES dbo.Usuarios (UsuarioId),
        IdMensaje     BIGINT    NOT NULL CONSTRAINT FK_ChatGuardados_Mensaje  REFERENCES chat.Mensajes (IdMensaje) ON DELETE CASCADE,
        FechaGuardado DATETIME2 NOT NULL CONSTRAINT DF_ChatGuardados_Fecha DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT PK_ChatGuardados PRIMARY KEY (IdUsuario, IdMensaje),
        INDEX IX_ChatGuardados_Usuario (IdUsuario, FechaGuardado)
    );
END

-- VERIFICACION (Archivos 7, EstadoUsuario 3, Mensajes 14, MensajesGuardados 3, Reacciones 4)
SELECT t.name AS Tabla, COUNT(c.column_id) AS Columnas
FROM sys.tables t
JOIN sys.columns c ON c.object_id = t.object_id
WHERE t.schema_id = SCHEMA_ID(N'chat')
GROUP BY t.name
ORDER BY t.name;
