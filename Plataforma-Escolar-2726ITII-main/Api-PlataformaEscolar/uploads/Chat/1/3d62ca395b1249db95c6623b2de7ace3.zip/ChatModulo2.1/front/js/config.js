// URL DEL BACK
const URL_DEL_BACK = "https://localhost:44342";

// USUARIO DE PRUEBAS (TODO-LOGIN: reemplazar por el usuario del login)
function obtenerUsuarioDePrueba() {
  const param = new URLSearchParams(window.location.search).get("usuario");
  if (param) sessionStorage.setItem("usuarioPrueba", param);
  const id = Number(sessionStorage.getItem("usuarioPrueba")) || 1;
  return { id: id, nombre: "Usuario " + id };
}

const CONFIG = {
  USAR_DATOS_DE_PRUEBA: false,

  API_URL: URL_DEL_BACK,

  USUARIO_ACTUAL: obtenerUsuarioDePrueba(),

  // TOKEN (TODO-LOGIN: confirmar dónde lo guarda el login)
  obtenerToken() {
    return sessionStorage.getItem("token");
  }
};